from django.shortcuts import render

def home(request):
    context = {
        'name': ' Umar Abdul Aziz Rabbani',
        'NIM': '0110225117',
        'description': 'Saya adalah seorang penghafal Al-Qur\'an dan mahasiswa Teknik Informatika yang bersemangat dalam belajar',
        'email': 'umarrabbani161206@gmail.com',
        'phone': '+62 895-2688-3075',
        'location': 'Jakarta, Indonesia'
    }
    return render(request, 'home.html', context)

def about(request):
    context = {
        'education': [
            {
                'degree': 'Sekolah Dasar Islam Terpadu',
                'institution': 'SDIT Fajar Hidayah Kota WIsata - SD Negri 1 CIangsana',
                'year': '2013 - 2019',
            },
            {
                'degree': 'Sekolah Menengah Pertama',
                'institution': 'SMP PTQ Fathan Mubiina',
                'year': '2019 - 2022',
            },
            {
                'degree': 'Sekolah Menengah Atas',
                'institution': 'SMA PTQ Fathan Mubiina',
                'year': '2012 - 2025',
            }
        ],
        'organizations': [
            {
                'role': 'Anggota',
                'organization': 'Anggota IST (osis) di pesantren',
                'year': '2024 - 2025',
                'description': 'Menjadi Anggota IST.'
            },
            {
                'role': 'Ketua',
                'organization': 'Ketua Bagian Penerimaan Tamu di Pesantren',
                'year': '2024 - 2025',
                'description': 'Menjadi Ketua Untuk Bagian Penerimaan Tamu.'
            },
            {
                'role': 'Anggota',
                'organization': 'BANTARA Pramuka',
                'year': '2023 - 2025',
                'description': 'Menjadi Anggota BANTARA Pramuka.'
            }
        ]
    }
    return render(request, 'about.html', context)

def gallery(request):
    context = {
        'images': [
            {
                'title': 'Mengawal',
                'description': 'Mengawal Pernikahan Anak Kyai di Pesantren',
                'url': 'images/foto1.jpeg'
            },
            {
                'title': 'Perpisahan',
                'description': 'Haflah dan Perpisahan Pesantren di Pulau Seribu',
                'url': 'images/foto4.jpeg'
            },
            {
                'title': 'Purna Tugas',
                'description': 'Penyerahan LPJ dan Serah Terima Jabatan di Pesantren',
                'url': 'images/foto3.jpeg'
            }
        ]
    }
    return render(request, 'gallery.html', context)
