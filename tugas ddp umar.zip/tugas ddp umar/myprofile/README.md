# Aplikasi Profile Django

Aplikasi web profile sederhana menggunakan Django dan Bootstrap.

## Instalasi

1. Install Django:
```bash
pip install django
```

2. Jalankan server:
```bash
cd myprofile
python manage.py runserver
```

3. Buka browser dan akses: http://127.0.0.1:8000

## Fitur

- Home: Profile diri dengan informasi kontak
- About Me: Riwayat pendidikan dan organisasi
- Gallery: Galeri foto kegiatan

## Struktur Folder

```
myprofile/
├── manage.py
├── settings.py
├── urls.py
├── wsgi.py
└── profile_app/
    ├── __init__.py
    ├── views.py
    ├── urls.py
    ├── templates/
    │   ├── base.html
    │   ├── home.html
    │   ├── about.html
    │   └── gallery.html
    └── static/
        └── css/
            └── style.css
```
